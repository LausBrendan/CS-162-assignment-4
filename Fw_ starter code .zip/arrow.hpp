#ifndef ARROW_HPP
#define ARROW_HPP

// TODO Arrow interface (define the arrow class and declare its member functions
// below)


#endif
