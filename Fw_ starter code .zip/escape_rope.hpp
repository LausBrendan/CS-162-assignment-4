#ifndef ESCAPE_ROPE_HPP
#define ESCAPE_ROPE_HPP

// TODO Escape rope interface (define the escape_rope class and declare its
// member functions below)


#endif
