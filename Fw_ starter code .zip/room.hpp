#ifndef ROOM_HPP
#define ROOM_HPP

#include "event.hpp"

// Room interface
class Room {
private: 
	// TODO private members
public:
	// TODO public members
};

#endif
