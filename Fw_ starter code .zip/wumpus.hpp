#ifndef WUMPUS_HPP
#define WUMPUS_HPP

// TODO Wumpus interface (define the wumpus class and declare its member
// functions below)


#endif
