#ifndef EVENT_HPP
#define EVENT_HPP

// Event interface
class event {
private:
	// TODO private members, if relevant
protected:
	// TODO protected members, if relevant
public:
	// TODO public members
};

#endif
