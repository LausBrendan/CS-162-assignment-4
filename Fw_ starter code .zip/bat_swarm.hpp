#ifndef BAT_SWARM_HPP
#define BAT_SWARM_HPP

// TODO Bat Swarm interface (define the bat_swarm class and declare its member
// functions below)


#endif
