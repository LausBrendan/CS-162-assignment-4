#ifndef GOLD_HPP
#define GOLD_HPP

// TODO Gold interface (define the gold class and declare its member functions
// below)


#endif
