#include "bottomless_pit.hpp"

// TODO Bottomless Pit implementation (define bottomless_pit member functions
// below)
