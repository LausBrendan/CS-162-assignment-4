#ifndef BOTTOMLESS_PIT_HPP
#define BOTTOMLESS_PIT_HPP

// TODO Bottomless Pit interface (define the bottomless_pit class and declare
// its member functions below)


#endif
