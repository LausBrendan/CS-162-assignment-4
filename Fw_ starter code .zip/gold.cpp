#include "gold.hpp"

// TODO Gold implementation (define gold member functions below)
