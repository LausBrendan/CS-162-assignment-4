#include "escape_rope.hpp"

// TODO Escape rope implementation (define escape_rope member functions below)
