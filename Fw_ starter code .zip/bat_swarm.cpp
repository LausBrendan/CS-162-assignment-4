#include "bat_swarm.hpp"

// TODO Bat Swarm implementation (define bat_swarm member functions below)
